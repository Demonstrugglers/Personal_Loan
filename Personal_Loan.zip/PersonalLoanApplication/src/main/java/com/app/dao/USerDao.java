package com.app.dao;

import java.util.List;

import com.app.model.LoanApply;
import com.app.model.LoanApproval;
import com.app.model.User;

public interface USerDao {
int register();
User login();
LoanApply apply();

LoanApply varifyLoanApplication();
LoanApproval approv();
List<User> listOfUsers();
List<LoanApply> listOfApplication();
List<LoanApproval> listOfapprove();
User findById(int id);

}
