package com.app.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import com.app.dao.USerDao;
import com.app.dto.UserRequest;
import com.app.model.LoanApply;
import com.app.model.LoanApproval;
import com.app.model.User;
import com.app.service.LoanApplyService;
import com.app.service.LoanApprovalService;
import com.app.service.UserService;

public class UserDaoImpl implements USerDao {
	

	public int register() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {SessionFactory factory=new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				session = factory.openSession();
			
			tx = session.beginTransaction();
			User user = new UserService().register();
			session.save(user);
			tx.commit();

			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public User login() {
		Session session = null;
		Transaction tx = null;
		User usResponse=new User();
		try {
			SessionFactory factory= new Configuration()
                    .configure("hibernate-cfg.xml")
		            .buildSessionFactory();
					session = factory.openSession();
		
			tx = session.beginTransaction();
			UserRequest user = new UserService().login();
			Query<User> query = session.createQuery(
					"From User where uname='" + user.getUname() + "' and password='" + user.getPassword() + "'");
			usResponse = query.uniqueResult();
				
			
			return usResponse;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
		}

	public LoanApply apply() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {SessionFactory factory=new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				session = factory.openSession();
			
			tx = session.beginTransaction();
			LoanApply loanapply = new LoanApplyService().apply();
			session.save(loanapply);
			tx.commit();

			return loanapply ;
		} catch (Exception e) {
			e.printStackTrace();
			return null ;
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	public LoanApply varifyLoanApplication() {
		
			USerDao dao=new UserDaoImpl();
			LoanApply loanApply = dao.apply();
			if(loanApply!=null && loanApply.getCibil()>=690 && loanApply.getLoanAmount() >= 99 && loanApply.getTermInYears()  >= 0 && loanApply.getTermInYears()<=10 )
			{
				System.out.println("Congratulations....!! Loan approve Succesfully");	
			}else {
				System.out.println("Sorry !!...You are not eligible for the loan");	
			}
			return loanApply;
		
			
	}
	public List<LoanApply> listOfApplication() {
		// TODO Auto-generated method stub
		SessionFactory factory= new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				Session	session = factory.openSession();
				@SuppressWarnings("unused")
				Transaction tx =session.beginTransaction();
				Query query=session.createQuery("From LoanApply  ");
		
		return query.list();
	}
	
	
	public List<User> listOfUsers() {
		// TODO Auto-generated method stub
		SessionFactory factory= new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				Session	session = factory.openSession();
				@SuppressWarnings("unused")
				Transaction tx =session.beginTransaction();
				Query query=session.createQuery("From User  ");
		
		return query.list();
	}

	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		SessionFactory factory= new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				Session	session = factory.openSession();
				Transaction tx =session.beginTransaction();
				Query query=session.createQuery("From User u where u.id=:id");
				query.setParameter("id", id);
				List<User> user=query.list();
		return user.get(0);
	}

	

	@Override
	public LoanApproval approv() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {SessionFactory factory=new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				session = factory.openSession();
			
			tx = session.beginTransaction();
			LoanApproval loanApproval = new LoanApprovalService().approv();
			session.save(loanApproval);
			tx.commit();

			return loanApproval ;
		} catch (Exception e) {
			e.printStackTrace();
			return null ;
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	public List<LoanApproval> listOfapprove() {
		// TODO Auto-generated method stub
		SessionFactory factory= new Configuration()
                .configure("hibernate-cfg.xml")
	            .buildSessionFactory();
				Session	session = factory.openSession();
				@SuppressWarnings("unused")
				Transaction tx =session.beginTransaction();
				Query query=session.createQuery("From LoanApproval  ");
		
		return query.list();
	}


}
