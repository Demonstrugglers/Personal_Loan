package com.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "LoanApply")
public class LoanApply {

	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Id
	private int custmoreId;
	private String loanType;
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	private int	loanAmount;
	private int termInYears;
	private int downPayment;
	private int cibil;
	public int getCibil() {
		return cibil;
	}
	public void setCibil(int cibil) {
		this.cibil = cibil;
	}
	public int getCustmoreId() {
		return custmoreId;
	}
	public void setCustmoreId(int custmoreId) {
		this.custmoreId = custmoreId;
	}
	public int getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}
	public int getTermInYears() {
		return termInYears;
	}
	public void setTermInYears(int termInYears) {
		this.termInYears = termInYears;
	}
	public int getDownPayment() {
		return downPayment;
	}
	public void setDownPayment(int downPayment) {
		this.downPayment = downPayment;
	}
	
	
	public LoanApply(int custmoreId, String loanType, int loanAmount, int termInYears, int downPayment, int cibil) {
		super();
		this.custmoreId = custmoreId;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
		this.termInYears = termInYears;
		this.downPayment = downPayment;
		this.cibil = cibil;
	}
	public LoanApply() {
		super();
	}
	@Override
	public String toString() {
		return "LoanApply [custmoreId=" + custmoreId + ", loanAmount=" + loanAmount + ", termInYears=" + termInYears
				+ ", downPayment=" + downPayment + "]";
	}
	
	
}
