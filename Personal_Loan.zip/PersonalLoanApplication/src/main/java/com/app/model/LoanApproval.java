package com.app.model;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;


@Entity
public class LoanApproval {

	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Id
	private int approvId;
	double monthlyPayment;
	double totalInterestAccrued;
	@OneToMany
	@JoinTable(name = "Custemor_name",
	joinColumns = @JoinColumn(name="approvId"),inverseJoinColumns =@JoinColumn(name="custmoreId"))
	private List<LoanApply> application;
	public int getApprovId() {
		return approvId;
	}
	public void setApprovId(int approvId) {
		this.approvId = approvId;
	}
	public double getMonthlyPayment() {
		return monthlyPayment;
	}
	public void setMonthlyPayment(double monthlyPayment) {
		this.monthlyPayment = monthlyPayment;
	}
	public double getTotalInterestAccrued() {
		return totalInterestAccrued;
	}
	public void setTotalInterestAccrued(double totalInterestAccrued) {
		this.totalInterestAccrued = totalInterestAccrued;
	}
	public List<LoanApply> getApplication() {
		return application;
	}
	public void setApplication(List<LoanApply> application) {
		this.application = application;
	}
	public LoanApproval(int approvId, double monthlyPayment, double totalInterestAccrued, List<LoanApply> application) {
		super();
		this.approvId = approvId;
		this.monthlyPayment = monthlyPayment;
		this.totalInterestAccrued = totalInterestAccrued;
		this.application = application;
	}
	public LoanApproval() {
		super();
	}

	   

}
