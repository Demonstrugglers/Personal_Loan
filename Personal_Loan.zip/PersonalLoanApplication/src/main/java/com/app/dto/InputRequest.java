package com.app.dto;

import java.util.Scanner;
import com.app.model.LoanApproval;
import com.app.model.LoanApply;
import com.app.model.User;

public class InputRequest {
	static  Scanner sn=new Scanner(System.in);
 public static User register() {
	
	 System.out.println("Enter User Details:");
	 System.out.println("Enter user first name:");
	 String fname=sn.next();
	 System.out.println("Enter user Last name:");
	 String lname=sn.next();
	 System.out.println("Enter user address:");
	 String address=sn.next();
	 System.out.println("Enter user mobile:");
	 long mob=sn.nextLong();
	 System.out.println("Enter user  name:");
	 String uname=sn.next();
	 System.out.println("Enter user password:");
	 String pass=sn.next();
	 System.out.println("Enter user role:");
	 String role=sn.next();
	return addUser(fname, lname, address, mob, uname, pass, role);
	 
 }
 private static User addUser(String fname, String lname, String address, long mob, String uname, String pass,
			String role) {
		User user=new User();
		 user.setAddress(address);
		 user.setFisrtName(fname);
		 user.setLastName(lname);
		 user.setMobile(mob);
		 user.setPassword(pass);
		 user.setRole(role);
		 user.setUname(uname);
		 return user;
	}
public static UserRequest login() {
	System.out.println("Enter user  name	:");
	 String uname=sn.next();
	 System.out.println("Enter user password:");
	 String pass=sn.next();
	 System.out.println("Enter user role	:");
	 String role=sn.next();
	 return new UserRequest(uname,pass,role);
 }
public static LoanApply apply() {
	String loanType;
	int loanAmount,termInYears,downPayment,cibil;
	System.out.println("Enter Loan Type 	:");
	loanType=sn.next();
	do {
		System.out.println("Enter Loan Amount 	:");
		loanAmount=sn.nextInt();
		if(loanAmount <= 99){
	         System.out.println("Loan amount must be greater than Rs99\n");
	    }
	}while(loanAmount <= 99);
	do {
		 System.out.println("Loan term in years	: ");
	     termInYears =sn.nextInt();
	     if(termInYears <= 0){
	         System.out.println("Loan term must be at least one year\n");
	     }
	     else if(termInYears > 50){
	         System.out.println("Loan term cannot exceed 50 years\n");
	     }
	}while(termInYears <=0 || termInYears> 50);
	do {
	     System.out.println("Downpayment Amount	: ");
	     downPayment =sn.nextInt();
	     if(downPayment < 0){
	         System.out.println("Downpayment cannot be negative, but can be Rs0\n");
	     }
	     else if(downPayment>=loanAmount){
	         System.out.println("Downpayment cannot equal or exceed your loan amount\n");
	     }
	}while(downPayment < 0 || downPayment >= loanAmount);
     System.out.println("Cibil Score		: ");
     cibil =sn.nextInt();
	return  addApply(loanType,loanAmount,termInYears,downPayment,cibil);
	
}

private static LoanApply addApply(String loanType,int loanAmount,int termInYears,int downPayment,int cibil )
{
	LoanApply loanapply = new LoanApply();
	loanapply.setLoanType(loanType);
	loanapply.setLoanAmount(loanAmount);
	loanapply.setTermInYears(termInYears);
	loanapply.setDownPayment(downPayment);
	loanapply.setCibil(cibil);
	return loanapply;
}

public static LoanApproval approv() {
	
		LoanApply loanapply = new  LoanApply();
		
		double loan= loanapply.getLoanAmount();
		int term= loanapply.getTermInYears();
		double rate=10+loanapply.getTermInYears();
		double downPay= loanapply.getDownPayment();
		
		double monthlyRate = (rate/100.0) / 12;
        int termsInMonths = term * 12;
        loan -= downPay;
        double monthlyPayment = (monthlyRate * loan)/(1-Math.pow((1+monthlyRate), -termsInMonths));
        
        double totalCost = monthlyPayment * termsInMonths;
        double totalInterestAccrued = totalCost - loan;
    
   
	return addApprov(monthlyPayment,totalInterestAccrued);
}
private static LoanApproval addApprov(double monthlyPayment,double totalInterestAccrued) {
	LoanApproval loanApproval = new LoanApproval();
				
	return loanApproval;
}

}