package com.app.test;

import java.io.IOException;

import java.util.List;
import java.util.Scanner;
import com.app.dao.USerDao;
import com.app.factory.UserFactory;
import com.app.model.LoanApply;
import com.app.model.LoanApproval;
import com.app.model.User;


public class Client {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
Scanner sn=new Scanner(System.in);

String ch="";
do {
	USerDao dao=UserFactory.getUser();
	System.out.println("========================PERSONAL LOAN APPLICATION============================");
	System.out.println("Press 1: for Register");
	System.out.println("Press 2: for Login");
	System.out.println("Press 3: for Display Users");
	System.out.println("Press 4: for Display User on id");
	System.out.println("-------------------------------");
	System.out.println("Enter Your Choice:");
	int choice=sn.nextInt();
	switch (choice) {
	case 1:
		int i=dao.register();
		if(i==1) {
			System.out.println("Successfully Register");
		}else {
			System.out.println("Something went wrong...!");
		}
		break;
	case 2:
		User user=dao.login();
		if(user!=null &&user.getRole().equalsIgnoreCase("admin")) {
			System.out.println("welcome to admin portal.");
			
			
		}else if(user!=null &&user.getRole().equalsIgnoreCase("user")){
			System.out.println("Welcome to user Portal..");
				//dao.apply();
				dao.varifyLoanApplication();
				dao.approv();
		}else {
			System.out.println("Invallid username and password");
		}
		break;
	case 3:
		List<User>list=dao.listOfUsers();
		list.stream().forEach(s->System.out.println(s.getId()+"\t\t"+s.getFisrtName()+"\t\t"+s.getLastName()+"\t\t"+s.getAddress()+"\t\t"+s.getMobile()));
		
		List<LoanApply>list2=dao.listOfApplication();
		System.out.println("------------------------------------------------------------------------------");
		list2.stream().forEach(s->System.out.println(s.getCustmoreId()+"\t\t"+s.getLoanType()+"\t\t"+s.getLoanAmount()+"\t\t"+s.getTermInYears()+"\t\t"+s.getDownPayment()+"\t"));
		
		List<LoanApproval>list3=dao.listOfapprove();
		System.out.println("------------------------------------------------------------------------------");
		list3.stream().forEach(s->System.out.println(s.getApprovId()+"\t\t"+s.getMonthlyPayment()+"\t\t"+s.getTotalInterestAccrued()));
	break;
	case 4:
		System.out.println("Enter your id for find user:");
		int id=sn.nextInt();
		User u1=dao.findById(id);
		System.out.println(u1);
		break;
	default:
		System.out.println("Invalid Request...!");
		break;
	}
	System.out.println("Do you want to continue...(y)");
	ch=sn.next();
}while(ch.equalsIgnoreCase("y"));
System.out.println("Thank you");
	}

}
