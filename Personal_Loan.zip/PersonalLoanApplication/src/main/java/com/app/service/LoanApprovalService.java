package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.LoanApproval;

public class LoanApprovalService {

	public LoanApproval approv() {
		return InputRequest.approv();
		
	}
}
