package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.LoanApply;

public class LoanApplyService {
	public LoanApply apply() {
		return InputRequest.apply();
		
	}
	public int verification() {
		return 0;
		
	}
	
}
